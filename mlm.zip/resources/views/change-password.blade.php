<x-app-layout>
    <!--sidebar wrapper -->
    @include('navigation-menu')
        <!--end sidebar wrapper -->
        <!--start header -->
        @include('header')
        <!--end header -->

        <!-- Page Content -->
        <div class="wrapper">

    <!--start page wrapper -->
    <div class="page-wrapper">
        <div class="page-content">
            
        </div>
    </div>
    <!--end page wrapper -->

    @include('footer')

</x-app-layout>
